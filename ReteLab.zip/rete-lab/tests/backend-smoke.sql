-- Collaudo su progetto configurato. Tutti i dati fittizi sono annullati dal ROLLBACK.
begin;
do $$declare teacher uuid:=gen_random_uuid(); outsider uuid:=gen_random_uuid(); begin
 insert into auth.users(id,email,aud,role) values(teacher,'retelab-test-owner@example.invalid','authenticated','authenticated'),(outsider,'retelab-test-other@example.invalid','authenticated','authenticated');
 insert into public.teachers values(teacher);
 perform set_config('retelab.teacher',teacher::text,true);
 perform set_config('retelab.outsider',outsider::text,true);
 perform set_config('request.jwt.claim.sub',teacher::text,true);
end $$;
set local role authenticated;
do $$declare eid uuid; code text; failed boolean; begin
 eid:=public.create_exam('TEST TEMPORANEO','SMOKE','standard',120,'[{"student":"TEST-01","pin":"TestPin-01"},{"student":"TEST-02","pin":"TestPin-02"}]');
 perform set_config('retelab.exam',eid::text,true);
 select e.code into code from public.exams e where id=eid;
 perform set_config('retelab.code',code,true);
 failed:=false;begin perform public.join_exam(code,'TEST-01','TestPin-01');exception when raise_exception then failed:=true;end;
 if not failed then raise exception 'FAIL: ingresso a prova chiusa';end if;
 perform public.set_exam_open(eid,true);
 if (select deadline from public.exams where id=eid) is null then raise exception 'FAIL: scadenza non fissata';end if;
 perform set_config('request.jwt.claim.sub',current_setting('retelab.outsider'),true);
 if exists(select 1 from public.exams where id=eid) then raise exception 'FAIL: altro docente vede prova';end if;
 failed:=false;begin perform public.create_exam('Vietata','SMOKE','standard',120,'[{"student":"TEST","pin":"TestPin-03"}]');exception when raise_exception then failed:=true;end;
 if not failed then raise exception 'FAIL: utente non abilitato crea prova';end if;
end $$;
reset role;
select set_config('request.jwt.claim.sub','',true);
set local role anon;
do $$declare data jsonb; failed boolean; token text; begin
 if has_table_privilege('anon','public.exams','select') or has_table_privilege('anon','public.roster','select') or has_table_privilege('anon','public.attempts','select') then raise exception 'FAIL: lettura tabelle anon';end if;
 if has_column_privilege('authenticated','public.attempts','token','select') then raise exception 'FAIL: token esposto ai docenti';end if;
 failed:=false;begin perform public.join_exam(current_setting('retelab.code'),'TEST-01','PIN-ERRATO');exception when raise_exception then failed:=true;end;
 if not failed then raise exception 'FAIL: PIN errato accettato';end if;
 data:=public.join_exam(current_setting('retelab.code'),'TEST-01','TestPin-01');token:=data->>'token';
 if length(token)<>64 then raise exception 'FAIL: token';end if;
 perform set_config('retelab.token1',token,true);
 if (public.join_exam(current_setting('retelab.code'),'TEST-01','TestPin-01')->>'token')<>token then raise exception 'FAIL: resume tentativo';end if;
 perform public.save_attempt(token,'{"version":1,"seed":"SMOKE","level":"standard","notes":"originale"}',false);
 perform public.save_attempt(token,'{"version":1,"seed":"SMOKE","level":"standard","notes":"consegnata"}',true);
 data:=public.save_attempt(token,'{"version":1,"seed":"SMOKE","level":"standard","notes":"modifica vietata"}',true);
 if not (data->>'already_submitted')::boolean then raise exception 'FAIL: consegna non bloccata';end if;
 data:=public.join_exam(current_setting('retelab.code'),'TEST-02','TestPin-02');token:=data->>'token';
 perform set_config('retelab.token2',token,true);
 perform public.save_attempt(token,'{"version":1,"seed":"SMOKE","level":"standard","notes":"bozza prima scadenza"}',false);
end $$;
reset role;
update public.exams set deadline=now()-interval '1 second' where id=current_setting('retelab.exam')::uuid;
set local role anon;
do $$declare data jsonb; failed boolean:=false;begin
 begin perform public.save_attempt(current_setting('retelab.token2'),'{"version":1,"seed":"SMOKE","level":"standard","notes":"dopo scadenza"}',false);exception when raise_exception then failed:=true;end;
 if not failed then raise exception 'FAIL: bozza tardiva accettata';end if;
 data:=public.save_attempt(current_setting('retelab.token2'),'{"notes":"dopo scadenza"}',true);
 if not (data->>'used_server_draft')::boolean then raise exception 'FAIL: non usa bozza precedente';end if;
end $$;
reset role;
do $$begin
 if (select answers->>'notes' from public.attempts where token=current_setting('retelab.token1'))<>'consegnata' then raise exception 'FAIL: consegna alterata';end if;
 if (select answers->>'notes' from public.attempts where token=current_setting('retelab.token2'))<>'bozza prima scadenza' then raise exception 'FAIL: contenuto tardivo registrato';end if;
 perform set_config('request.jwt.claim.sub',current_setting('retelab.teacher'),true);
end $$;
set local role authenticated;
do $$begin
 if (select count(*) from public.attempts where exam_id=current_setting('retelab.exam')::uuid)<>2 then raise exception 'FAIL: docente non vede consegne';end if;
 perform public.delete_exam(current_setting('retelab.exam')::uuid);
end $$;
reset role;
do $$begin
 if exists(select 1 from public.attempts where exam_id=current_setting('retelab.exam')::uuid) or exists(select 1 from public.roster where exam_id=current_setting('retelab.exam')::uuid) then raise exception 'FAIL: cancellazione incompleta';end if;
end $$;
select 'PASS: accesso docente, RLS, PIN, ripresa, bozze, consegna immutabile, scadenza e cancellazione' as result;
rollback;
