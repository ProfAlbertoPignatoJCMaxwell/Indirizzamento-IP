-- Eseguire UNA VOLTA nel SQL Editor di un nuovo progetto Supabase.
-- Non pubblicare dati di studenti in GitHub. Questo file contiene solo lo schema.
begin;
create schema if not exists extensions;
create extension if not exists pgcrypto with schema extensions;
create schema retelab_private;
revoke all on schema retelab_private from public;
grant usage on schema retelab_private to anon,authenticated;
create table public.teachers (user_id uuid primary key references auth.users(id) on delete cascade);
create table public.exams (
 id uuid primary key default gen_random_uuid(), owner_id uuid not null references auth.users(id),
 title text not null check(length(title) between 1 and 120),
 code text not null unique default upper(encode(extensions.gen_random_bytes(6),'hex')),
 seed text not null check(seed ~ '^[A-Za-z0-9_-]{1,40}$'),
 level text not null check(level in ('base','standard','sfida')), engine_version int not null default 1,
 duration_minutes int not null check(duration_minutes between 15 and 240),
 is_open boolean not null default false, deadline timestamptz, created_at timestamptz not null default now()
);
create table public.roster (
 exam_id uuid references public.exams(id) on delete cascade,
 student_id text not null check(length(student_id) between 1 and 40), pin_hash text not null,
 primary key(exam_id,student_id)
);
create table public.attempts (
 id uuid primary key default gen_random_uuid(),exam_id uuid not null references public.exams(id) on delete cascade,
 student_id text not null, token text not null unique default encode(extensions.gen_random_bytes(32),'hex'),
 started_at timestamptz not null default now(),submitted_at timestamptz, answers jsonb not null default '{}',
 unique(exam_id,student_id), foreign key(exam_id,student_id) references public.roster(exam_id,student_id)
);
alter table public.teachers enable row level security;
alter table public.exams enable row level security;
alter table public.roster enable row level security;
alter table public.attempts enable row level security;
revoke all on public.teachers,public.exams,public.roster,public.attempts from anon,authenticated;
grant select on public.exams to authenticated;
grant select(id,exam_id,student_id,started_at,submitted_at,answers) on public.attempts to authenticated;
create policy exams_owner on public.exams for select to authenticated using(owner_id=(select auth.uid()));
create policy attempts_owner on public.attempts for select to authenticated using(exists(select 1 from public.exams e where e.id=exam_id and e.owner_id=(select auth.uid())));
create policy teachers_no_direct_access on public.teachers for all to anon,authenticated using(false) with check(false);
create policy roster_no_direct_access on public.roster for all to anon,authenticated using(false) with check(false);

create index exams_owner_created_idx on public.exams(owner_id,created_at desc);
create function retelab_private.create_exam(p_title text,p_seed text,p_level text,p_minutes int,p_roster jsonb)
returns uuid language plpgsql security definer set search_path='' as $$
declare eid uuid; item jsonb;
begin
 if not exists(select 1 from public.teachers where user_id=auth.uid()) then raise exception 'Docente non abilitato'; end if;
 if jsonb_typeof(p_roster) is distinct from 'array' or jsonb_array_length(p_roster) not between 1 and 100 then raise exception 'Inserire da 1 a 100 studenti'; end if;
 insert into public.exams(owner_id,title,seed,level,duration_minutes) values(auth.uid(),p_title,p_seed,p_level,p_minutes) returning id into eid;
 for item in select value from jsonb_array_elements(p_roster) loop
  if length(coalesce(item->>'pin','')) not between 6 and 64 then raise exception 'Ogni PIN deve contenere da 6 a 64 caratteri'; end if;
  if length(trim(coalesce(item->>'student',''))) not between 1 and 40 then raise exception 'Identificativo studente non valido'; end if;
  insert into public.roster values(eid,trim(item->>'student'),extensions.crypt(item->>'pin',extensions.gen_salt('bf',6)));
 end loop;
 return eid;
end $$;
create function retelab_private.set_exam_open(p_id uuid,p_open boolean)
returns void language plpgsql security definer set search_path='' as $$
begin
 update public.exams set is_open=p_open,deadline=case when p_open and deadline is null then now()+make_interval(mins=>duration_minutes) else deadline end where id=p_id and owner_id=auth.uid();
 if not found then raise exception 'Verifica non accessibile'; end if;
end $$;
create function retelab_private.delete_exam(p_id uuid)
returns void language plpgsql security definer set search_path='' as $$
begin
 delete from public.exams where id=p_id and owner_id=auth.uid();
 if not found then raise exception 'Verifica non accessibile'; end if;
end $$;
-- Gli studenti si autenticano con codice/PIN e token opaco del tentativo, senza account Auth.
create function retelab_private.join_exam(p_code text,p_student text,p_pin text)
returns jsonb language plpgsql security definer set search_path='' as $$
declare e public.exams; r public.roster; a public.attempts;
begin
 select * into e from public.exams where code=upper(trim(p_code));
 if not found then raise exception 'Codice o credenziali non validi'; end if;
 select * into r from public.roster where exam_id=e.id and student_id=trim(p_student) for update;
 if not found or extensions.crypt(p_pin,r.pin_hash) is distinct from r.pin_hash then raise exception 'Codice o credenziali non validi'; end if;
 select * into a from public.attempts where exam_id=e.id and student_id=r.student_id;
 if a.id is null then
  if not e.is_open or e.deadline is null or now()>=e.deadline then raise exception 'La verifica non è aperta'; end if;
  insert into public.attempts(exam_id,student_id) values(e.id,r.student_id) returning * into a;
 end if;
 return jsonb_build_object('exam_id',e.id,'seed',e.seed,'level',e.level,'token',a.token,'deadline',e.deadline,'answers',a.answers,'submitted',a.submitted_at is not null);
end $$;
create function retelab_private.save_attempt(p_token text,p_answers jsonb,p_final boolean)
returns jsonb language plpgsql security definer set search_path='' as $$
declare a public.attempts; e public.exams; draft boolean:=false;
begin
 if p_token is null or length(p_token)<>64 then raise exception 'Sessione non valida'; end if;
 select * into a from public.attempts where token=p_token for update;
 if not found then raise exception 'Sessione non valida'; end if;
 select * into e from public.exams where id=a.exam_id;
 if a.submitted_at is not null then return jsonb_build_object('received_at',a.submitted_at,'already_submitted',true); end if;
 if not e.is_open then raise exception 'Il docente ha chiuso la prova. Contattalo per la consegna.'; end if;
 if now()>=e.deadline then
  if not p_final then raise exception 'Tempo scaduto'; end if;
  -- Dopo la scadenza si può confermare SOLO l'ultima bozza già sul server.
  draft:=true;
 else
  if jsonb_typeof(p_answers) is distinct from 'object' or octet_length(p_answers::text)>100000 then raise exception 'Risposte non valide o troppo grandi'; end if;
  if (p_answers->>'version') is distinct from e.engine_version::text or (p_answers->>'seed') is distinct from e.seed or (p_answers->>'level') is distinct from e.level then raise exception 'Versione o traccia non corrispondente'; end if;
  update public.attempts set answers=p_answers where id=a.id;
 end if;
 if p_final then update public.attempts set submitted_at=now() where id=a.id; end if;
 return jsonb_build_object('received_at',now(),'used_server_draft',draft);
end $$;
revoke all on all functions in schema retelab_private from public,anon,authenticated;
grant execute on function retelab_private.create_exam(text,text,text,int,jsonb),retelab_private.set_exam_open(uuid,boolean),retelab_private.delete_exam(uuid) to authenticated;
grant execute on function retelab_private.join_exam(text,text,text),retelab_private.save_attempt(text,jsonb,boolean) to anon,authenticated;
-- API pubblica senza privilegi elevati; le implementazioni privilegiate non sono esposte da PostgREST.
create function public.create_exam(p_title text,p_seed text,p_level text,p_minutes int,p_roster jsonb)
returns uuid language sql security invoker set search_path='' as $$select retelab_private.create_exam(p_title,p_seed,p_level,p_minutes,p_roster)$$;
create function public.set_exam_open(p_id uuid,p_open boolean)
returns void language sql security invoker set search_path='' as $$select retelab_private.set_exam_open(p_id,p_open)$$;
create function public.delete_exam(p_id uuid)
returns void language sql security invoker set search_path='' as $$select retelab_private.delete_exam(p_id)$$;
create function public.join_exam(p_code text,p_student text,p_pin text)
returns jsonb language sql security invoker set search_path='' as $$select retelab_private.join_exam(p_code,p_student,p_pin)$$;
create function public.save_attempt(p_token text,p_answers jsonb,p_final boolean)
returns jsonb language sql security invoker set search_path='' as $$select retelab_private.save_attempt(p_token,p_answers,p_final)$$;
revoke all on function public.create_exam(text,text,text,int,jsonb),public.set_exam_open(uuid,boolean),public.delete_exam(uuid),public.join_exam(text,text,text),public.save_attempt(text,jsonb,boolean) from public,anon,authenticated;
grant execute on function public.create_exam(text,text,text,int,jsonb),public.set_exam_open(uuid,boolean),public.delete_exam(uuid) to authenticated;
grant execute on function public.join_exam(text,text,text),public.save_attempt(text,jsonb,boolean) to anon,authenticated;
commit;

-- DOPO aver creato l'utente docente in Authentication > Users, eseguire a parte:
-- insert into public.teachers(user_id) values ('UUID-REALE-UTENTE-DOCENTE');
